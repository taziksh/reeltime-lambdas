import boto3  
import time
def lambda_handler(event, context):  
    client = boto3.client('mediaconvert')  
    endpoint = client.describe_endpoints()['Endpoints'][0]['Url']
    print("endpoint to the mediaconvert job is")
    print(endpoint)
    print("media convert completion job running")
    print(event)
    myclient = boto3.client('mediaconvert', endpoint_url=endpoint)
    
    while True:
        response = myclient.list_jobs(MaxResults=1,  Order='DESCENDING')
        Status = response['Jobs'][0]['Status']
        if Status == 'COMPLETE':
            print("MediaConvert job is complete.")
            break
        elif Status in ['ERROR', 'CANCELED']:
            print("MediaConvert job encountered an error or was canceled.")
            break
        else:
            print("MediaConvert job is still in progress. Checking again in 3 seconds.")
            time.sleep(1)
    
    print("media convert job complettion lambda done")
    print(Status)
    return {
            'statusCode': 201,
            'body': response['Jobs'][0]['Status']
    }
 
        
    