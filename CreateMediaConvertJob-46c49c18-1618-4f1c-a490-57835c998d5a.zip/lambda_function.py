import json
import boto3

    
def lambda_handler(event, context):
    s3_location = 's3://'
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']
    print("mediaconvert job triggered")
    s3_location += bucket_name
    s3_location+='/'
    s3_location +=object_key
    print(s3_location)
    try:
        with open('mediaconvert.json') as f:
            data = json.load(f)
    
        client = boto3.client('mediaconvert')
        endpoint = client.describe_endpoints()['Endpoints'][0]['Url']

        myclient = boto3.client('mediaconvert', endpoint_url=endpoint)

        data['Settings']['Inputs'][0]['FileInput'] = s3_location
        print("CREATING JOB")
        response = myclient.create_job(
            Queue=data['Queue'],
            Role=data['Role'],
            Settings=data['Settings'])
            
        state_machine_arn = 'arn:aws:states:us-east-1:829102044026:stateMachine:FeatureVectorCreationStep'
        
        stepfunctions_client = boto3.client('stepfunctions')
        # Start the Step Function execution
        print("calling step function")
        response = stepfunctions_client.start_execution(
            stateMachineArn=state_machine_arn
        )
        execution_arn = response['executionArn']
        print("Step Function execution started with ARN: {execution_arn}")
        return {
            'statusCode': 200,
            'body': 'Job created successfully'
        }
    except Exception as e:
        print("error",str(e))
        return {
            'statusCode': 500,
            'body': str(e)
        }
