import json
import boto3

    
def lambda_handler(event, context):
    try:
        print("running extract clip")
        with open('mediaconvert.json') as f:
            data = json.load(f)

        print("json loaded")
        print("startTime before is ",data['Settings']['Inputs'][0]['InputClippings'][0]['StartTimecode'])
        data['Settings']['Inputs'][0]['InputClippings'][0]['StartTimecode'] = event['startTime']
        print("new startTime is",event['startTime'])
        print("endtime before is ",data['Settings']['Inputs'][0]['InputClippings'][0]['EndTimecode'])
        data['Settings']['Inputs'][0]['InputClippings'][0]['EndTimecode'] = event['endTime']
        fileName='-'+event['startTime']+'_'+event['label']
        data['Settings']['OutputGroups'][0]["Outputs"][0]["NameModifier"]=fileName
        print(" new endtime is",event['endTime'])
        videoName='s3://soccer-reels-video-upload/'
        videoName+=event['videoName']
        print(videoName)
        data['Settings']['Inputs'][0]["FileInput"]=videoName
        client = boto3.client('mediaconvert')
        print(" created client")
        endpoint = client.describe_endpoints()['Endpoints'][0]['Url']
        print("endpoint is ",endpoint)
        myclient = boto3.client('mediaconvert', endpoint_url=endpoint)
        print("created extract clip job")
        response = myclient.create_job(
            Queue=data['Queue'],
            Role=data['Role'],
            Settings=data['Settings'])
        print("response is ",response)
        return {
            'statusCode': 200,
            'body': 'Job created successfully'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }
