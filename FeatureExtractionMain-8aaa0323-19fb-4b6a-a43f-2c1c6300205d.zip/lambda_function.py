import json
import boto3

def list_files(bucket_name,folder_prefix):
    s3_client = boto3.client('s3')
    paginator = s3_client.get_paginator('list_objects_v2')
    pages= paginator.paginate(Bucket=bucket_name,Prefix=folder_prefix)
    files=[]
    for page in pages:
        if 'Contents' in page:
            files.extend(obj['Key'] for obj in page['Contents'])
    return files
        
def lambda_handler(event, context):
    client = boto3.client('lambda')
    files=list_files('reeltimes3','Thumbnails/')
    BATCH_SIZE = 100
    
    chunks = [files[i:i + BATCH_SIZE] for i in range(1, len(files), BATCH_SIZE)]
    
    print("feature extraction main running")
    print(len(chunks))

    for chunk in chunks:
        response = client.invoke(
            FunctionName='FeatureExtractionTriggerer',
            InvocationType='Event',
            Payload=json.dumps({'files': chunk})
        )
        
    return  {
            'statusCode': 200
    }