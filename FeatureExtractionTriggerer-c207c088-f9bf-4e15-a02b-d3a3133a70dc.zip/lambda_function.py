import json
import boto3



def lambda_handler(event, context):
    client = boto3.client('lambda')
    print("feature extraction triggerer running")
    print(len(event.get('files', [])))
    for file in event.get('files', []):
        print("sending file to mxnet")
        print(file)
        response = client.invoke(
            FunctionName='reeltime-mxnet-lambda',
            InvocationType='Event',
            Payload=json.dumps({'filename': file,'bucketname':'reeltimes3'})
            )
    return
    