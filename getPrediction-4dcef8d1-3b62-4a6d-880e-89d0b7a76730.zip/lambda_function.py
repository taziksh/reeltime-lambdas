import json
import boto3
import concurrent.futures
import botocore
import re

client_config = botocore.config.Config(
    max_pool_connections=200
)
s3 = boto3.client('s3',config=client_config)
# Create SQS client
sqs = boto3.client('sqs')

# Define the URL of your SQS queue
queue_url = 'https://sqs.us-east-1.amazonaws.com/829102044026/prediction-queue.fifo'
def list_filenames_in_bucket(bucket_name,prefix):
     # Call S3 to list current buckets
    if prefix!='/':
        response = s3.list_objects_v2(Bucket=bucket_name,Prefix=prefix)
    else:
        response = s3.list_objects_v2(Bucket=bucket_name)
        
    # List of filenames
    filenames = []

        # Iterate over the objects in the bucket
    if 'Contents' in response:
        for obj in response['Contents']:
            filenames.append(obj['Key'])
        return filenames
    return []
def parse_prediction(query_response):
    model_predictions = json.loads(query_response['Body'].read())
    predicted_label = model_predictions['predicted_label']
    probability = model_predictions['probability']
    return predicted_label, probability
    
def predict_top_k_labels(probabilities, labels,k):
    topk_prediction_ids = sorted(range(len(probabilities)), key=lambda index: probabilities[index], reverse=True)[:k]
    topk_class_labels = labels[topk_prediction_ids[0]]
    return topk_class_labels
    
def query_endpoint(img):
    endpoint_name = 'canvas-new-deployment-03-02-2024-10-31-PM'
    client = boto3.client('runtime.sagemaker')
    response = client.invoke_endpoint(EndpointName=endpoint_name, ContentType='application/x-image', Body=img, Accept='application/json')
    return response
    
def invoke_sagemaker(payload):
    bucket = 'reeltimes3'
    try:
        response = s3.get_object(Bucket=bucket, Key=payload)
    except Exception as e:
        print("Error getting object:", e)
        print("error key is ",payload)
        return None
        
    image_data = response['Body'].read()
    model_predictions = query_endpoint(image_data)
    predicted_label, probability = parse_prediction(model_predictions)
    return (payload,predicted_label,probability)
    
def format_time(seconds, fps=25):
    # Convert seconds to integer
    seconds = int(seconds)

    # Calculate hours, minutes, seconds, and fractions of a second
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    f = int((seconds - int(seconds)) * fps)

    # Format the time components
    time_str = "{:02d}:{:02d}:{:02d}:{:02d}".format(int(h), int(m), int(s), int(f))
    return time_str
    
def parsed_time(data):
    match_first = re.search(r'[^.]+\.(?:0*(\d+))\.jpg', data)
    startTime=0
    if match_first:
        number_str = match_first.group(1)  # Extract the captured group
        number = int(number_str)
        return number
def get_events(data):
    list_times = []
    i = 0
    while i < len(data):
        start_time = parsed_time(data[i][0])
        counter = 1
        prev_time = start_time
        for j in range(i+1,len(data)):
            check_time = parsed_time(data[j][0])
            counter += 1
            if check_time != (prev_time+1) or j==(len(data)-1) :
                end_time = parsed_time(data[j-1][0])
                if end_time - start_time + 1 >= 4:
                    list_times.append((start_time,end_time))
                i=j
                print(i)
                break
            prev_time = check_time
        if i==len(data)-1:
            break
    return list_times
    
def lambda_handler(event, context):
    print("start of the function")
    print("running concurrent threads")
    filenames= list_filenames_in_bucket('reeltimes3','Thumbnails/')
    filenames.pop(0)
    print("len of filename is ",len(filenames))
    results = []
    batch_size = 100
    batches = [filenames[i:i+batch_size] for i in range(0, len(filenames), batch_size)]
    videoNames= list_filenames_in_bucket('soccer-reels-video-upload','/')
    for batch in batches:
        # Use ThreadPoolExecutor to invoke SageMaker endpoint concurrently
        with concurrent.futures.ThreadPoolExecutor(max_workers=200) as executor:
            # Submit tasks
            futures = [executor.submit(invoke_sagemaker, payload) for payload in batch]
            # Gather results
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                results.append(result)
            # assume 1 penalty scene
    
    penalty_scenes = [item for item in results if item[1] == "penalty" and item[2] >0.9]
    print("len of pen scene is ",len(penalty_scenes))
    ref_scenes = [item for item in results if item[1] == "ref" and item[2] > 0.9]
    print("len of ref scene is ",len(ref_scenes))
    sorted_penalty_data = sorted(penalty_scenes, key=lambda x: x[0])
    sorted_ref_data = sorted(ref_scenes, key=lambda x: x[0])
    print(sorted_penalty_data)
    print(sorted_ref_data)
    penalty_events= get_events(sorted_penalty_data)
    ref_events= get_events(sorted_ref_data)
    lambda_client = boto3.client('lambda')
    print('length of ref event is',len(ref_events))
    print(ref_events)
    for item in ref_events:
        # Parameters for the target Lambda function
        function_name = 'ExtractClip'
        invocation_type = 'Event'
        startTime= 0
        if item[0]>=3:
            startTime= format_time(item[0]-3)
        else:
            startTime= format_time(item[0])
        endTime = format_time(item[1])
        video=videoNames[0]
        # Example payload to pass to the target Lambda function
        payload = {
            'startTime': startTime,
            'endTime': endTime,
            'videoName':video,
            'label':'ref'
        }
        print(payload)
        try:
            # Invoke the target Lambda function
            response = lambda_client.invoke(
                FunctionName='ExtractClip',
                InvocationType='Event',
                Payload=json.dumps(payload)
            )
        except Exception as e:
            print("Error invoking Lambda function:", e)
            return None
    for item in penalty_events:
        # Parameters for the target Lambda function
        function_name = 'ExtractClip'
        invocation_type = 'Event'
        startTime= 0
        if item[0]>=2:
            startTime= format_time(item[0]-2)
        else:
            startTime= format_time(item[0])
        endTime = format_time(item[1])
        video=videoNames[0]
        # Example payload to pass to the target Lambda function
        payload = {
            'startTime': startTime,
            'endTime': endTime,
            'videoName':video,
            'label':'penalty'
        }
        print(payload)
        try:
            # Invoke the target Lambda function
            response = lambda_client.invoke(
                FunctionName='ExtractClip',
                InvocationType='Event',
                Payload=json.dumps(payload)
            )
        except Exception as e:
            print("Error invoking Lambda function:", e)
            return None
    
    return {
        'statusCode': 200,
    }